<?php
$email = $_POST['email'];
$pass = $_POST['pass'];
$conn= new mysqli("localhost","root","","lp");

$q = "select * from user where email like '".$email."' and pass like '".$pass."'";
$sd =$conn->query($q);
$row = $sd->fetch_assoc();
if ( $row === NULL) {
  header ("Location:login.php");
} else {
  session_start();
  $_SESSION["fname"] = $row["fanme"]; 
   $_SESSION["lname"] = $row["lanme"];
  header ("Location:welcome.php");
   }
?>