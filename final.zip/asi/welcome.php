<?php

$conn = new mysqli("localhost","root","", "lp");
       $q="select* from user";
       $sd = $conn->query($q);
       echo "<table border=2px solid black >";
    echo "<tr>";
    echo "<th>";
    echo "Id";
    echo "</th>";
    
    echo "<th>";
    echo "first name";
    echo "</th>";
    
    echo "<th>";
    echo "email";
    echo "</th>";
    
    echo "<th>";
    echo "current semester";
    echo "</th>";
    
    echo "</tr>";
    
    while($row = $sd->fetch_assoc())
    {
      echo "<tr>";
      echo "<td>";
      echo $row["id"];
      echo "</td>";
      
      echo "<td>";
      echo $row["fname"];
      echo "</td>";
      
      echo "<td>";
      echo $row["email"];
      echo "</td>";
      
      echo "<td>";
      echo $row["sem"];
      echo "</td>";
      
	  echo "<td>";
      echo "<a href = 'delete.php?id=".$row["id"]."' >";
	  echo "delete";
	  echo "</a>";
      echo "</td>";

	  echo "<td>";
      echo "<a href = 'update.php?id=".$row["id"]."' >";
	  echo "Update";
	  echo "</a>";
      echo "</td>";

      echo "</tr>";
    }
       echo "</table>";
      
?>