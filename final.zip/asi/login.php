<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login page</title>
    <link rel="stylesheet" href="style3.css">
</head>
<body>
    <div class="con">
        <h1> Enter Info to Login </h1>
        <form action="check.php" method="POST">
        <input class="in" type="email" name="email" required placeholder="Enter email"><br>
        <input class="in" type="password" name="pass" required placeholder="Enter Password"><br>
        <input class="btn"type="submit" value="Login">
        </form>
    </div>
    
</body>
</html>