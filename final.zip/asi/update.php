<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
<?php
$id = $_GET['id'];
   $conn = new mysqli("localhost","root","", "lp");
   $q="select* from user where id =".$id."";
   $sd = $conn->query($q);
   $row = $sd->fetch_assoc();

?>
	<form action="updateData.php" method="POST">
		<input type="text" name="id" value ="<?php echo $id; ?>" > <br>
		<input type="text" name="fname" value ="<?php echo $row['fname']; ?>" > <br>
		<input type="email" name="email" value ="<?php echo $row['email']; ?>" ><br>
		<input type="int" name="sem" value ="<?php echo $row['sem']; ?>" ><br>
		<input type="submit" value="save my data">
	</form>
</body>
</html>