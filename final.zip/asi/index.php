<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Coffee login </title>
    <link rel="stylesheet" href="style3.css">
</head>
<body>
    
    <div class="con">
        <h1> Enter Info to sign up </h1>
        <form action="signup.php" method="POST">
		<input class="in" type="text" name="username" required placeholder="Enter first name"> <br>
        <input class="in" type="text" name="lname" required  placeholder="Enter last name"> <br>
		<input class="in" type="email" name="email" placeholder="Enter email"><br>
		<input class="in" type="password" name="pass" required placeholder="Enter Password"><br>
		<input class="in" type="password" required placeholder="ReEnter Password"><br>
        <input class="in" type="cnic"  required  pattren = /^[0-9]{5}-[0-9]{7}-[0-9]{1}$/ placeholder="Enter cnic"><br>
        <input type="radio" id="html" name="gender" required value="HTML">
        <label for="html">Male</label><br>
        <input type="radio" id="css" name="gender" required value="CSS">
        <label for="css">Female</label><br>

           <select name="sem" id="sem" placeholder ="Select current semester">
            <option >Select current semester</option>
            <option value="1">1</option>
            <option value="2">2</option>
            <option value="3">3</option>
            <option value="4">4</option>
            </select>
            <br>
            <input type="checkbox" id="agree" name="agree" required value="1">
            <label for="agree" > agree with terms and conditions</label> <br>
		<input class="btn" type="submit" value="SignUp">
	</form>
    <button class="btn"><a class="btn" href="login.php"> Login <br></a></button>
    
    </div>

   
</body>
</html>