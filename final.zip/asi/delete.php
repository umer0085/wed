<?php
$id = $_GET['id'];
       $conn = new mysqli("localhost","root","", "lp");

       
//delete querry
$sql = "DELETE FROM user WHERE id=".$id."";
if ($conn->query($sql) === TRUE) {
header ("Location:welcome.php");
} else {
echo "Error deleting record: " . $conn->error;
}
?>